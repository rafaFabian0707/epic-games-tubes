<?php

namespace App\Http\Controllers;

use App\Models\Game;
use App\Models\News;

class HomeController extends Controller
{
    public function index()
    {
        $featuredGames = Game::active()->baseGame()
            ->with(['publisher', 'discounts', 'platforms'])
            ->orderByDesc('avg_rating')
            ->limit(6)->get();

        $freeGames = Game::active()->free()
            ->with(['publisher'])
            ->inRandomOrder()
            ->limit(4)->get();

        $latestNews = News::where('is_active', true)
            ->latest('news_id')
            ->limit(3)->get();

        return view('home', compact('featuredGames', 'freeGames', 'latestNews'));
    }
}
